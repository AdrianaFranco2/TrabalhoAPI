package org.serratec.trabIndividual.FuncionarioApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuncionarioApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
